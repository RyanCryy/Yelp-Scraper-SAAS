"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { updateUserToPaid } from "@/app/actions/update-user-status"

export default function UpdateUserPage() {
  const router = useRouter()
  const [isLoading, setIsLoading] = useState(false)
  const [message, setMessage] = useState<string | null>(null)

  async function handleUpdateUser() {
    setIsLoading(true)
    setMessage("Updating user status...")

    try {
      const result = await updateUserToPaid()

      if (result.success) {
        setMessage("User successfully updated to paid status! Redirecting to dashboard...")
        setTimeout(() => {
          router.push("/dashboard")
        }, 2000)
      } else {
        setMessage(`Error: ${result.message}`)
      }
    } catch (error: any) {
      setMessage(`Error: ${error.message}`)
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50">
      <div className="max-w-md w-full p-8 bg-white rounded-lg shadow-lg text-center">
        <h1 className="text-2xl font-bold mb-6">Update User Status</h1>
        <p className="mb-6">
          This will update the user <strong>ryanchamruiyang@gmail.com</strong> to paid Pro status.
        </p>

        {message && (
          <div
            className={`p-4 mb-6 rounded-md ${message.includes("Error") ? "bg-red-50 text-red-600" : "bg-blue-50 text-blue-600"}`}
          >
            {message}
          </div>
        )}

        <Button onClick={handleUpdateUser} className="w-full bg-blue-600 hover:bg-blue-700" disabled={isLoading}>
          {isLoading ? "Updating..." : "Update to Paid Status"}
        </Button>

        <div className="mt-4">
          <Button onClick={() => router.push("/dashboard")} variant="outline" className="w-full">
            Back to Dashboard
          </Button>
        </div>
      </div>
    </div>
  )
}


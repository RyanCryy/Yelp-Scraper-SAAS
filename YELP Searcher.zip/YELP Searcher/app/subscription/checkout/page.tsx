"use client"

import { useState, useEffect } from "react"
import { useSearchParams, useRouter } from "next/navigation"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ArrowLeft, CreditCard } from "lucide-react"
import Link from "next/link"

export default function CheckoutPage() {
  const searchParams = useSearchParams()
  const router = useRouter()
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    // Check if the user canceled the checkout
    const canceled = searchParams.get("canceled")
    if (canceled) {
      setError("Payment was canceled. Please try again.")
    }
  }, [searchParams])

  const handleCheckout = async () => {
    setIsLoading(true)
    setError(null)

    try {
      const response = await fetch("/api/create-checkout-session", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({}),
      })

      const data = await response.json()

      if (data.success && data.url) {
        // Redirect to Stripe Checkout
        window.location.href = data.url
      } else {
        setError(data.message || "An error occurred. Please try again.")
      }
    } catch (err: any) {
      console.error("Payment error:", err)
      setError("An unexpected error occurred. Please try again.")
    } finally {
      setIsLoading(false)
    }
  }

  const plan = {
    name: "Pro Plan",
    price: "$29",
    period: "per month",
    features: [
      "Unlimited searches",
      "Export to CSV",
      "Email verification",
      "Phone number verification",
      "Priority support",
    ],
  }

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="container mx-auto px-4 max-w-4xl">
        <Link href="/dashboard" className="inline-flex items-center text-sm text-blue-600 mb-8">
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to Dashboard
        </Link>

        <div className="grid md:grid-cols-5 gap-8">
          <div className="md:col-span-3">
            <Card>
              <CardHeader>
                <CardTitle>Complete Your Subscription</CardTitle>
                <CardDescription>
                  You're subscribing to the {plan.name} at {plan.price} {plan.period}
                </CardDescription>
              </CardHeader>
              <CardContent>
                {error && <div className="mb-4 p-3 bg-red-50 text-red-600 rounded-md">{error}</div>}

                <Button
                  onClick={handleCheckout}
                  className="w-full bg-blue-600 hover:bg-blue-700 flex items-center justify-center"
                  disabled={isLoading}
                >
                  <CreditCard className="mr-2 h-4 w-4" />
                  {isLoading ? "Processing..." : `Proceed to Payment`}
                </Button>
              </CardContent>
              <CardFooter className="flex flex-col items-start text-sm text-gray-500">
                <p>Your subscription will renew automatically each month.</p>
                <p>You can cancel anytime from your account settings.</p>
                <p className="mt-2">Secure payment processing by Stripe.</p>
              </CardFooter>
            </Card>
          </div>

          <div className="md:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle>Order Summary</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between">
                    <span>{plan.name}</span>
                    <span>{plan.price}</span>
                  </div>
                  <div className="border-t pt-4">
                    <div className="flex justify-between font-medium">
                      <span>Total</span>
                      <span>{plan.price}</span>
                    </div>
                    <div className="text-sm text-gray-500 mt-1">Billed {plan.period}</div>
                  </div>
                </div>

                <div className="mt-6">
                  <h4 className="font-medium mb-2">What's included:</h4>
                  <ul className="space-y-1">
                    {plan.features.map((feature, index) => (
                      <li key={index} className="text-sm flex items-start">
                        <span className="text-green-500 mr-2">✓</span>
                        {feature}
                      </li>
                    ))}
                  </ul>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}


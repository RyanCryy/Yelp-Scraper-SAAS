"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"

export default function SetUserPage() {
  const router = useRouter()
  const [isLoading, setIsLoading] = useState(true)
  const [message, setMessage] = useState("Setting user to Ryan...")

  useEffect(() => {
    async function setUser() {
      try {
        const response = await fetch("/api/set-user")
        const data = await response.json()

        if (data.success) {
          setMessage("User successfully set to Ryan!")
          // Redirect to dashboard after a short delay
          setTimeout(() => {
            router.push("/dashboard")
          }, 1500)
        } else {
          setMessage(`Error: ${data.message}`)
        }
      } catch (error) {
        setMessage("An unexpected error occurred")
      } finally {
        setIsLoading(false)
      }
    }

    setUser()
  }, [router])

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50">
      <div className="max-w-md w-full p-8 bg-white rounded-lg shadow-lg text-center">
        <h1 className="text-2xl font-bold mb-6">User Configuration</h1>

        {isLoading ? (
          <div className="flex flex-col items-center">
            <div className="w-10 h-10 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mb-4"></div>
            <p>{message}</p>
          </div>
        ) : (
          <>
            <p className="mb-6">{message}</p>
            <Button onClick={() => router.push("/dashboard")} className="bg-blue-600 hover:bg-blue-700">
              Go to Dashboard
            </Button>
          </>
        )}
      </div>
    </div>
  )
}


"use client"

import { useState } from "react"
import Link from "next/link"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { LockIcon, AlertTriangle } from "lucide-react"

interface UpgradePromptProps {
  isExpired: boolean
  trialEndsAt: Date
}

export function UpgradePrompt({ isExpired, trialEndsAt }: UpgradePromptProps) {
  const [isOpen, setIsOpen] = useState(isExpired)

  // Calculate days left in trial
  const now = new Date()
  const trialEndDate = new Date(trialEndsAt)
  const daysLeft = Math.max(0, Math.ceil((trialEndDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24)))

  // If not expired but close to expiration (1 day left), show a warning
  const isCloseToExpiration = !isExpired && daysLeft <= 1

  if (!isExpired && !isCloseToExpiration) {
    return null
  }

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            {isExpired ? (
              <>
                <LockIcon className="h-5 w-5 text-red-500" />
                Your Free Trial Has Expired
              </>
            ) : (
              <>
                <AlertTriangle className="h-5 w-5 text-yellow-500" />
                Your Free Trial Is Ending Soon
              </>
            )}
          </DialogTitle>
          <DialogDescription>
            {isExpired
              ? "Your free trial has ended. Upgrade to the Pro plan to continue accessing all features."
              : `Your free trial will expire in ${daysLeft} day${daysLeft !== 1 ? "s" : ""}. Upgrade now to avoid interruption.`}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <h3 className="text-sm font-medium">With the Pro plan, you get:</h3>
            <ul className="list-disc pl-5 text-sm text-gray-500 space-y-1">
              <li>Unlimited searches</li>
              <li>Export to CSV</li>
              <li>Email verification</li>
              <li>Phone number verification</li>
              <li>Priority support</li>
            </ul>
          </div>
        </div>

        <DialogFooter className="flex flex-col sm:flex-row gap-2">
          <Button variant="outline" onClick={() => setIsOpen(false)} className="sm:w-auto w-full">
            {isExpired ? "Continue with Limited Access" : "Remind Me Later"}
          </Button>
          <Button asChild className="sm:w-auto w-full bg-blue-600 hover:bg-blue-700">
            <Link href="/subscription/checkout">Upgrade Now</Link>
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}


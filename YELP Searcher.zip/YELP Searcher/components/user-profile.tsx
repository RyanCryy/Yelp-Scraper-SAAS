interface UserProfileProps {
  user: {
    email: string
    name: string
    company: string
    phoneNumber: string
    country: string
    isAdmin: boolean
    accountType?: "free" | "paid"
    subscription?: {
      plan: "trial" | "pro" | "enterprise"
      status: "active" | "canceled" | "past_due" | "unpaid"
      trialEndsAt: Date
    }
  } | null
}

export function UserProfile({ user }: UserProfileProps) {
  if (!user) return null

  // Calculate days left in trial if applicable
  const daysLeft = user.subscription
    ? Math.max(0, Math.ceil((new Date(user.subscription.trialEndsAt).getTime() - Date.now()) / (1000 * 60 * 60 * 24)))
    : 0

  // Check if trial has expired
  const isExpired = user.accountType === "free" && user.subscription?.plan === "trial" && daysLeft === 0

  return (
    <div>
      <h2 className="text-xl font-medium text-gray-900 mb-6">User Profile</h2>

      <div className="space-y-6">
        <div>
          <p className="text-sm text-gray-500 mb-1">Email</p>
          <p className="text-base text-gray-900">{user.email}</p>
        </div>

        <div>
          <p className="text-sm text-gray-500 mb-1">Full Name</p>
          <p className="text-base text-gray-900">{user.name}</p>
        </div>

        <div>
          <p className="text-sm text-gray-500 mb-1">Company</p>
          <p className="text-base text-gray-900">{user.company}</p>
        </div>

        <div className="grid gap-6 sm:grid-cols-2">
          <div>
            <p className="text-sm text-gray-500 mb-1">Phone Number</p>
            <p className="text-base text-gray-900">{user.phoneNumber}</p>
          </div>

          <div>
            <p className="text-sm text-gray-500 mb-1">Country</p>
            <p className="text-base text-gray-900">{user.country}</p>
          </div>
        </div>

        <div className="flex flex-wrap gap-2">
          {user.isAdmin && (
            <div className="mt-1">
              <span className="inline-block px-2 py-1 text-xs text-gray-600 bg-gray-100 rounded">Admin</span>
            </div>
          )}

          <div className="mt-1">
            <span
              className={`inline-block px-2 py-1 text-xs rounded ${
                user.accountType === "paid"
                  ? "bg-green-100 text-green-600"
                  : isExpired
                    ? "bg-red-100 text-red-600"
                    : "bg-blue-100 text-blue-600"
              }`}
            >
              {user.accountType === "paid"
                ? "Paid Account"
                : isExpired
                  ? "Free (Expired)"
                  : `Free (${daysLeft} days left)`}
            </span>
          </div>
        </div>
      </div>
    </div>
  )
}

